import { describe, it, expect } from "vitest";
import { planChunks } from "../src/core/planChunks.js";

describe("planChunks", () => {
  it("F-01: 3時間を10分で切ると18区間", () => {
    expect(planChunks(10800, 600)).toHaveLength(18);
  });

  it("N-03: 端数が0.024秒しかなければ前にまとめる（19区間にならない）", () => {
    const r = planChunks(10800.024, 600);
    expect(r).toHaveLength(18);
    expect(r[17].end).toBe(10800.024);
  });

  it("U-10: 3分0.5秒を1分で切ると3区間（最後の0.5秒は前へ）", () => {
    const r = planChunks(180.5, 60);
    expect(r).toHaveLength(3);
    expect(r[2]).toEqual({ start: 120, end: 180.5 });
  });

  it("境界: 端数がちょうど1秒なら、まとめずに1区間として残す", () => {
    expect(planChunks(61, 60)).toHaveLength(2);
  });

  it("U-11: 全体が区間より短いなら1区間", () => {
    expect(planChunks(20, 60)).toEqual([{ start: 0, end: 20 }]);
  });

  it("区間はすき間も重なりもなく、全体を覆う", () => {
    const r = planChunks(1234.5, 300);
    expect(r[0].start).toBe(0);
    for (let i = 1; i < r.length; i++) expect(r[i].start).toBe(r[i - 1].end);
    expect(r[r.length - 1].end).toBe(1234.5);
  });

  it("異常系: 0・負・数でない値は例外", () => {
    expect(() => planChunks(0, 60)).toThrow();
    expect(() => planChunks(60, 0)).toThrow();
    expect(() => planChunks(-1, 60)).toThrow();
    expect(() => planChunks("abc", 60)).toThrow();
  });
});
