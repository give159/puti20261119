import { build } from "esbuild";
import { readFileSync, writeFileSync, mkdirSync } from "node:fs";

const js = (await build({
  entryPoints: ["src/app.js"], bundle: true, format: "iife",
  minify: false, write: false,
})).outputFiles[0].text;

const css = readFileSync("src/style.css", "utf8");
const html = readFileSync("src/template.html", "utf8")
  .replace("/*CSS*/", () => css)
  .replace("<!--APP-->", () => js);

mkdirSync("dist", { recursive: true });
writeFileSync("dist/chunkplan.html", html);
console.log("built dist/chunkplan.html", (html.length / 1024).toFixed(1) + "KB");
