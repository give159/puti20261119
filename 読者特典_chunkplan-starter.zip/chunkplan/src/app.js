import { planChunks } from "./core/planChunks.js";

const $ = (id) => document.getElementById(id);

$("run").addEventListener("click", () => {
  $("error").textContent = "";
  $("list").textContent = "";
  try {
    const plan = planChunks(Number($("totalMin").value) * 60, Number($("splitMin").value) * 60);
    $("summary").textContent = "分割数：" + plan.length;
    for (const c of plan) {
      const li = document.createElement("li");
      li.textContent = (c.start / 60).toFixed(2) + "分 〜 " + (c.end / 60).toFixed(2) + "分";
      $("list").appendChild(li);
    }
  } catch (e) {
    $("summary").textContent = "";
    $("error").textContent = "入力を確かめてください：" + e.message;
  }
});
