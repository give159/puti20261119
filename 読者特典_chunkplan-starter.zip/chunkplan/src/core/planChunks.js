// 音声の全体の長さ（秒）を、決めた長さごとの区間に分ける。
// 最後の区間が minTailSec 未満なら、1つ前の区間にまとめる（要件 N-03）。
export function planChunks(totalSec, chunkSec, minTailSec = 1) {
  if (!(totalSec > 0)) throw new Error("totalSec は 0 より大きい数");
  if (!(chunkSec > 0)) throw new Error("chunkSec は 0 より大きい数");

  const chunks = [];
  const count = Math.ceil(totalSec / chunkSec);
  for (let i = 0; i < count; i++) {
    const start = i * chunkSec;
    const end = Math.min(start + chunkSec, totalSec);
    chunks.push({ start, end });
  }

  const last = chunks[chunks.length - 1];
  if (chunks.length > 1 && last.end - last.start < minTailSec) {
    chunks.pop();
    chunks[chunks.length - 1].end = totalSec;
  }
  return chunks;
}
