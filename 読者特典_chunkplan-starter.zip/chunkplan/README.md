# 分割プランナー（『プチツール開発入門』読者特典）

音声の長さと分割単位から、区間の一覧を出す、HTML1枚のプチツールです。

## 使い方（Node.js v22以上）

```bash
npm ci
npm run verify      # テスト → ビルド → 点検
```

`dist/chunkplan.html` をブラウザで開きます。

## 構成

- `src/core/planChunks.js` 計算だけ（画面を知らない）
- `src/app.js` 画面とつなぐ
- `src/template.html` / `src/style.css` 見た目
- `tests/` テスト（要件IDを名前に入れている）
- `build.mjs` ソースを1枚のHTMLにまとめる
- `check.mjs` 配布物の点検

## 守ること

- 直すのは `src/` と `tests/`。`dist/` は直さない
- `npm audit fix --force` は実行しない（部品の版が変わる）

動作確認：Node.js v22.23.5 / esbuild 0.24.2 / vitest 2.1.9（2026年11月）
