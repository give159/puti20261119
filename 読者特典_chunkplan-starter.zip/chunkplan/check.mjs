// 配布物の点検：外部への参照が混ざっていないか
import { readFileSync } from "node:fs";
const html = readFileSync("dist/chunkplan.html", "utf8");
const bad = html.match(/(src|href)=["']https?:\/\//g);
if (bad) { console.error("外部参照あり:", bad); process.exit(1); }
if (html.includes("<!--APP-->") || html.includes("/*CSS*/")) { console.error("目印が残っている"); process.exit(1); }
console.log("check OK（外部参照なし・目印残りなし）");
